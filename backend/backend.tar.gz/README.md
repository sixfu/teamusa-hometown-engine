# Team USA API - Backend

## 快速开始

### 1. 安装依赖
```bash
python -m venv venv
source venv/bin/activate  # Mac/Linux
# 或
venv\Scripts\activate  # Windows

pip install -r requirements.txt
```

### 2. 配置环境变量
```bash
cp .env.example .env
# 编辑.env，填入GCP_PROJECT_ID
```

### 3. 运行
```bash
python main.py
```

访问 http://localhost:5000/health 验证

## API端点

- `GET /api/hometowns` - 获取所有hometowns
- `GET /api/hometowns/by-state` - 按州汇总
- `GET /api/hometowns/search?city_name=...` - 搜索hometown
- `GET /api/sports` - 获取所有sports
- `GET /api/hometown/<hometown_id>` - 获取hometown详情

## 部署到Cloud Run

```bash
gcloud run deploy team-usa-api --source . --platform managed --region us-central1
```
