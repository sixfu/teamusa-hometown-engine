import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    GCP_PROJECT_ID = os.getenv('GCP_PROJECT_ID')
    BQ_DATASET_ID = 'team_usa_olympics'
    
    # BigQuery表名
    BQ_ATHLETES_TABLE = f'{GCP_PROJECT_ID}.{BQ_DATASET_ID}.athletes'
    BQ_HOMETOWNS_TABLE = f'{GCP_PROJECT_ID}.{BQ_DATASET_ID}.hometowns'
    BQ_SPORTS_TABLE = f'{GCP_PROJECT_ID}.{BQ_DATASET_ID}.sports'
    
    # Vertex AI配置
    GEMINI_MODEL = 'gemini-1.5-flash'
    GEMINI_REGION = 'us-central1'
    
    DEBUG = os.getenv('DEBUG', 'True') == 'True'
