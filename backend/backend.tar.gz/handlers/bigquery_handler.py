from google.cloud import bigquery
from config import Config

class BigQueryHandler:
    def __init__(self):
        self.client = bigquery.Client(project=Config.GCP_PROJECT_ID)
    
    def get_all_hometowns(self):
        """返回所有hometown及其运动员数量"""
        query = f"""
        SELECT 
            hometown_id,
            city_name,
            state_code,
            latitude,
            longitude,
            total_athletes
        FROM `{Config.BQ_HOMETOWNS_TABLE}`
        ORDER BY total_athletes DESC
        """
        
        results = self.client.query(query).to_dataframe()
        return results.to_dict(orient='records')
    
    def get_hometowns_by_state(self):
        """按州汇总hometowns数据"""
        query = f"""
        SELECT 
            state_code,
            SUM(total_athletes) as total_athletes_in_state,
            COUNT(*) as num_cities
        FROM `{Config.BQ_HOMETOWNS_TABLE}`
        GROUP BY state_code
        ORDER BY total_athletes_in_state DESC
        """
        
        results = self.client.query(query).to_dataframe()
        return results.to_dict(orient='records')
    
    def search_hometown(self, city_name=None, state_code=None):
        """搜索specific hometown"""
        query = f"""
        SELECT 
            hometown_id,
            city_name,
            state_code,
            latitude,
            longitude,
            total_athletes
        FROM `{Config.BQ_HOMETOWNS_TABLE}`
        WHERE 1=1
        """
        
        if city_name:
            query += f" AND LOWER(city_name) LIKE LOWER('%{city_name}%')"
        if state_code:
            query += f" AND state_code = '{state_code.upper()}'"
        
        query += " ORDER BY total_athletes DESC LIMIT 20"
        
        results = self.client.query(query).to_dataframe()
        return results.to_dict(orient='records')
    
    def get_all_sports(self):
        """返回所有运动项目及其运动员数量"""
        query = f"""
        SELECT 
            sport_id,
            sport_name,
            total_us_athletes
        FROM `{Config.BQ_SPORTS_TABLE}`
        ORDER BY total_us_athletes DESC
        """
        
        results = self.client.query(query).to_dataframe()
        return results.to_dict(orient='records')
    
    def get_hometown_details(self, hometown_id):
        """获取某个hometown的详细信息"""
        query = f"""
        SELECT 
            hometown_id,
            city_name,
            state_code,
            latitude,
            longitude,
            total_athletes
        FROM `{Config.BQ_HOMETOWNS_TABLE}`
        WHERE hometown_id = '{hometown_id}'
        LIMIT 1
        """
        
        hometown = self.client.query(query).to_dataframe().to_dict(orient='records')
        if not hometown:
            return None
        
        hometown_data = hometown[0]
        
        # 该hometown的top sports
        city_name = hometown_data['city_name']
        state_code = hometown_data['state_code']
        
        query_sports = f"""
        SELECT 
            s.sport_name,
            COUNT(DISTINCT a.athlete_id) as count
        FROM `{Config.BQ_ATHLETES_TABLE}` a
        WHERE a.birth_city = '{city_name}' AND a.birth_state = '{state_code}'
        GROUP BY s.sport_name
        ORDER BY count DESC
        LIMIT 10
        """
        
        try:
            top_sports = self.client.query(query_sports).to_dataframe().to_dict(orient='records')
            hometown_data['top_sports'] = top_sports
        except:
            hometown_data['top_sports'] = []
        
        return hometown_data
