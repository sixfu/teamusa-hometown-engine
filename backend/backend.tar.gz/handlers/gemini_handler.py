from vertexai.generative_models import GenerativeModel
from config import Config

class GeminiHandler:
    def __init__(self):
        self.model = GenerativeModel(Config.GEMINI_MODEL)
    
    def generate_hometown_story(self, hometown_data):
        """为某个hometown生成故事"""
        
        city_name = hometown_data.get('city_name', 'Unknown')
        state_code = hometown_data.get('state_code', 'Unknown')
        total_athletes = hometown_data.get('total_athletes', 0)
        top_sports = hometown_data.get('top_sports', [])
        
        # 构建prompt
        sports_text = ", ".join([f"{s['sport_name']} ({s['count']} athletes)" 
                                  for s in top_sports[:3]])
        
        prompt = f"""
你是一个关于美国奥运历史的专家。请为以下城镇生成一段引人入胜的故事，
说明为什么这个地方培养了这么多奥运选手。

城镇信息：
- 城市名: {city_name}
- 州: {state_code}
- 奥运选手总数: {total_athletes}
- 主要运动项目: {sports_text}

要求：
1. 用2-3段话简明扼要地说明
2. 可以提到当地的地理位置、气候、历史背景或文化特点
3. 用条件语气，如"可能有助于"、"也许是因为"，而不是绝对陈述
4. 不要编造具体的历史事实，只基于逻辑推理
5. 语言要易于理解，适合展示在网站上

生成故事：
"""
        
        response = self.model.generate_content(prompt)
        return response.text
