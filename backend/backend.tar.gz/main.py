from flask import Flask, jsonify, request
from flask_cors import CORS
from handlers.bigquery_handler import BigQueryHandler
from handlers.gemini_handler import GeminiHandler
import os

app = Flask(__name__)
CORS(app)

# 初始化handlers
bq = BigQueryHandler()
gemini = GeminiHandler()

# ═══════════════════════════════════════════════════════════
# API 端点定义
# ═══════════════════════════════════════════════════════════

# API 1: 获取所有hometowns
@app.route('/api/hometowns', methods=['GET'])
def get_hometowns():
    """
    获取所有hometown及其运动员数量
    """
    try:
        data = bq.get_all_hometowns()
        return jsonify({
            'success': True,
            'data': data
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# API 2: 按州汇总
@app.route('/api/hometowns/by-state', methods=['GET'])
def get_hometowns_by_state():
    """
    按州汇总hometown数据
    用于州级地图热力图
    """
    try:
        data = bq.get_hometowns_by_state()
        return jsonify({
            'success': True,
            'data': data
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# API 3: 搜索hometown
@app.route('/api/hometowns/search', methods=['GET'])
def search_hometown():
    """
    搜索hometown
    
    查询参数:
    - city_name: 城市名 (可选)
    - state_code: 州代码 (可选)
    """
    city_name = request.args.get('city_name')
    state_code = request.args.get('state_code')
    
    try:
        data = bq.search_hometown(city_name, state_code)
        return jsonify({
            'success': True,
            'data': data
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# API 4: 获取所有sports
@app.route('/api/sports', methods=['GET'])
def get_sports():
    """
    获取所有运动项目及其运动员数量
    """
    try:
        data = bq.get_all_sports()
        return jsonify({
            'success': True,
            'data': data
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# API 5: 获取hometown详情 + 生成Gemini故事
@app.route('/api/hometown/<hometown_id>', methods=['GET'])
def get_hometown_detail(hometown_id):
    """
    获取某个hometown的详细信息
    包括: 城市名、州、运动员数、主要运动项目、AI生成的故事
    """
    try:
        hometown_data = bq.get_hometown_details(hometown_id)
        if not hometown_data:
            return jsonify({
                'success': False,
                'error': 'Hometown not found'
            }), 404
        
        # 生成Gemini故事
        story = gemini.generate_hometown_story(hometown_data)
        hometown_data['story'] = story
        
        return jsonify({
            'success': True,
            'data': hometown_data
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# API 6: 健康检查
@app.route('/health', methods=['GET'])
def health_check():
    """
    用于Cloud Run部署的健康检查
    """
    return jsonify({'status': 'ok'}), 200

# ═══════════════════════════════════════════════════════════

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
